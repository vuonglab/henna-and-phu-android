If you use this dove image in your own work, please pay for it at:

https://marketplace.zibbet.com/vectordesign/bird-dove-animal-graphics-svg-dxf-eps-png-cdr-ai-pdf-vector-art-clipart-instant-download-digital-cut-print-file-cricut-silhouette-decal